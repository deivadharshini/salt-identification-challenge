## Pull Request template to the [TGS Salt Identification](https://www.kaggle.com/c/tgs-salt-identification-challenge) Open Solution

Major - and most appreciated - contribution is pull request with feature or bug fix. Each pull request initiates discussion about your code contribution.

Each pull request should be provided with minimal description about its contents.
#

Thanks!

Kuba & Kamil,

_core contributors to the Open Solutions_
